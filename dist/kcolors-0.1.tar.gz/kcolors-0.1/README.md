# kcolors
Automátic ANSI colors for Python Scripts (static colors too)
