from .colors import Colors


RED = Colors.Red
print(f"SE HA IMPORTADO RED")
